import math
import os
from datetime import date
from typing import Optional

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

load_dotenv()
API_KEY = os.getenv("API_FOOTBALL_KEY", "").strip()
API_BASE = "https://v3.football.api-sports.io"

app = FastAPI(title="SCORE EXACT API", version="0.2.0")

allowed_origins = [
    origin.strip()
    for origin in os.getenv("CORS_ORIGINS", "http://localhost:8080").split(",")
    if origin.strip()
]
app.add_middleware(
    CORSMiddleware,
    allow_origins=allowed_origins,
    allow_credentials=False,
    allow_methods=["GET"],
    allow_headers=["*"],
)


async def football_get(path: str, params: dict):
    if not API_KEY or API_KEY == "COLLER_LA_CLE_ICI_COTE_SERVEUR":
        raise HTTPException(
            status_code=503,
            detail="Clé API non configurée côté serveur. Ajoutez API_FOOTBALL_KEY dans le fichier .env.",
        )

    headers = {"x-apisports-key": API_KEY}
    try:
        async with httpx.AsyncClient(timeout=20.0) as client:
            response = await client.get(
                f"{API_BASE}/{path}", params=params, headers=headers
            )
            response.raise_for_status()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Le fournisseur football ne répond pas à temps.")
    except httpx.HTTPStatusError as exc:
        status = exc.response.status_code
        # Do not expose provider response bodies, which may contain sensitive details.
        raise HTTPException(status_code=502, detail=f"Erreur du fournisseur de données (HTTP {status}).")
    except httpx.RequestError:
        raise HTTPException(status_code=502, detail="Impossible de joindre le fournisseur de données football.")

    try:
        data = response.json()
    except ValueError:
        raise HTTPException(status_code=502, detail="Réponse invalide du fournisseur de données football.")

    errors = data.get("errors")
    if errors:
        raise HTTPException(status_code=502, detail={"provider_errors": errors})
    return data


@app.get("/health")
def health():
    return {
        "app": "SCORE EXACT",
        "status": "ok",
        "api_key_configured": bool(API_KEY and API_KEY != "COLLER_LA_CLE_ICI_COTE_SERVEUR"),
    }


@app.get("/api/leagues")
async def leagues(
    season: Optional[int] = Query(default=None, ge=2000, le=2100),
    country: Optional[str] = Query(default=None, min_length=2, max_length=80),
):
    params = {}
    if season is not None:
        params["season"] = season
    if country:
        params["country"] = country.strip()
    data = await football_get("leagues", params)
    return {"results": data.get("response", []), "paging": data.get("paging", {})}


@app.get("/api/fixtures")
async def fixtures(
    day: date = Query(default_factory=date.today),
    league: Optional[int] = Query(default=None, ge=1),
    season: Optional[int] = Query(default=None, ge=2000, le=2100),
    timezone: str = Query(default="Africa/Ndjamena", min_length=1, max_length=64),
):
    params = {"date": day.isoformat(), "timezone": timezone}
    if league is not None:
        params["league"] = league
    if season is not None:
        params["season"] = season
    data = await football_get("fixtures", params)
    return {"results": data.get("response", []), "paging": data.get("paging", {})}


def poisson(k: int, lam: float) -> float:
    if k < 0 or lam < 0 or not math.isfinite(lam):
        raise ValueError("k et lambda doivent être positifs et lambda doit être fini.")
    return math.exp(-lam) * (lam**k) / math.factorial(k)


def top_scores(home_lambda: float, away_lambda: float, max_goals: int = 7):
    if not (math.isfinite(home_lambda) and math.isfinite(away_lambda)):
        raise ValueError("Les paramètres de buts doivent être finis.")
    if home_lambda < 0 or away_lambda < 0:
        raise ValueError("Les paramètres de buts ne peuvent pas être négatifs.")

    scores = []
    for home_goals in range(max_goals + 1):
        for away_goals in range(max_goals + 1):
            probability = poisson(home_goals, home_lambda) * poisson(away_goals, away_lambda)
            scores.append(
                {
                    "score": f"{home_goals}-{away_goals}",
                    "probability": round(probability, 6),
                    "probability_percent": round(probability * 100, 2),
                }
            )
    return sorted(scores, key=lambda item: item["probability"], reverse=True)[:5]


@app.get("/api/analysis")
def analysis(
    home_ht: float = Query(default=0.55, ge=0, le=5),
    away_ht: float = Query(default=0.35, ge=0, le=5),
    home_ft: float = Query(default=1.35, ge=0, le=8),
    away_ft: float = Query(default=1.05, ge=0, le=8),
):
    half_time = top_scores(home_ht, away_ht, 7)
    full_time = top_scores(home_ft, away_ft, 10)
    return {
        "method": "Poisson indépendant (prototype)",
        "half_time": half_time,
        "full_time": full_time,
        "warning": (
            "Prototype uniquement : les paramètres de buts sont fournis manuellement. "
            "Les probabilités ne sont pas calibrées sur les historiques des équipes et "
            "ne constituent pas une garantie de résultat."
        ),
    }
