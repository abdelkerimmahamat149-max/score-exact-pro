import os, math
from datetime import date
from typing import Optional
import httpx
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

load_dotenv()
API_KEY = os.getenv("API_FOOTBALL_KEY", "")
API_BASE = "https://v3.football.api-sports.io"

app = FastAPI(title="SCORE EXACT API", version="0.1.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:8080").split(","),
    allow_credentials=False, allow_methods=["GET"], allow_headers=["*"]
)

async def football_get(path: str, params: dict):
    if not API_KEY:
        raise HTTPException(503, "Clé API non configurée côté serveur.")
    headers = {"x-apisports-key": API_KEY}
    async with httpx.AsyncClient(timeout=20) as client:
        response = await client.get(f"{API_BASE}/{path}", params=params, headers=headers)
    if response.status_code != 200:
        raise HTTPException(response.status_code, "Erreur du fournisseur de données football.")
    data = response.json()
    if data.get("errors"):
        raise HTTPException(502, {"provider_errors": data["errors"]})
    return data

@app.get("/health")
def health():
    return {"app": "SCORE EXACT", "status": "ok", "api_key_configured": bool(API_KEY)}

@app.get("/api/leagues")
async def leagues(season: int = Query(default=2026, ge=2000, le=2100), country: Optional[str] = None):
    params = {"season": season}
    if country:
        params["country"] = country
    data = await football_get("leagues", params)
    return {"results": data.get("results", []), "paging": data.get("paging", {})}

@app.get("/api/fixtures")
async def fixtures(day: date = Query(default_factory=date.today), league: Optional[int] = None,
                   season: Optional[int] = None, timezone: str = "Africa/Ndjamena"):
    params = {"date": day.isoformat(), "timezone": timezone}
    if league is not None: params["league"] = league
    if season is not None: params["season"] = season
    data = await football_get("fixtures", params)
    return {"results": data.get("response", []), "paging": data.get("paging", {})}

def poisson(k: int, lam: float) -> float:
    return math.exp(-lam) * (lam ** k) / math.factorial(k)

def top_scores(home_lambda: float, away_lambda: float, max_goals: int = 7):
    scores = []
    for h in range(max_goals + 1):
        for a in range(max_goals + 1):
            scores.append({"score": f"{h}-{a}", "probability": poisson(h, home_lambda) * poisson(a, away_lambda)})
    return sorted(scores, key=lambda x: x["probability"], reverse=True)[:5]

@app.get("/api/analysis")
def analysis(home_ht: float = Query(0.55, ge=0, le=5),
             away_ht: float = Query(0.35, ge=0, le=5),
             home_ft: float = Query(1.35, ge=0, le=8),
             away_ft: float = Query(1.05, ge=0, le=8)):
    ht = top_scores(home_ht, away_ht, 5)
    ft = top_scores(home_ft, away_ft, 7)
    return {
        "method": "Poisson indépendant (prototype)",
        "half_time": ht,
        "full_time": ft,
        "warning": "Estimations conditionnées par les lambdas fournis. Ce modèle ne constitue pas une garantie et n'est pas encore calibré sur l'historique."
    }
