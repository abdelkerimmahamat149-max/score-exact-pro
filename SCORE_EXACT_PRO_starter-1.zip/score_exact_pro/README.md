# SCORE EXACT Pro — socle technique v0.1

Ce dossier contient un prototype frontend et une API backend. Il ne s'agit pas encore d'une application Android publiée ni d'un service hébergé.

## Architecture
- `frontend/index.html` : interface mobile web de test.
- `backend/main.py` : API FastAPI, accès fournisseur côté serveur, endpoints matchs/compétitions et Poisson de base.
- La clé fournisseur doit rester dans le backend. Ne jamais la placer dans le HTML, l'application Android, une capture d'écran ou un message public.

## Fournisseur de données
Le backend est préparé pour API-Football (`https://v3.football.api-sports.io`) avec l'en-tête `x-apisports-key`. Il faut créer un compte, choisir un abonnement adapté, puis configurer la clé dans `backend/.env`.

## Lancement local
1. Installer Python 3.10+.
2. Dans `backend/`, créer un environnement virtuel et installer `pip install -r requirements.txt`.
3. Copier `.env.example` vers `.env`, puis renseigner `API_FOOTBALL_KEY` localement.
4. Lancer `uvicorn main:app --reload --host 0.0.0.0 --port 8000`.
5. Ouvrir `frontend/index.html` dans un navigateur. Si nécessaire, servir le dossier frontend avec un serveur HTTP local et adapter `CORS_ORIGINS`.

## Endpoints
- `GET /health`
- `GET /api/leagues?season=2026`
- `GET /api/fixtures?day=2026-11-26&timezone=Africa/Ndjamena`
- `GET /api/analysis?home_ht=0.55&away_ht=0.35&home_ft=1.35&away_ft=1.05`

## Étapes indispensables avant production
- Héberger le backend en HTTPS et stocker la clé dans des secrets serveur.
- Vérifier les droits d'utilisation et la couverture réelle de chaque compétition/saison.
- Ajouter cache, limites d'appels, surveillance d'erreurs et gestion des quotas.
- Construire les variables de buts attendus à partir de données historiques vérifiées, pas de valeurs arbitraires.
- Calibrer et tester hors échantillon les prédictions HT et FT; afficher la couverture des données et les probabilités calibrées.
- Ajouter comptes, sécurité, politique de confidentialité, conditions d'utilisation et facturation avant lancement commercial.
- Emballer le frontend dans une application Android (par exemple via une WebView sécurisée ou une application native).

## Limites actuelles
La route Poisson est une démonstration mathématique utilisant des buts attendus fournis en paramètres. Elle n'analyse pas encore automatiquement la forme des équipes et ne doit pas être présentée comme un modèle validé ou une garantie de gains.
