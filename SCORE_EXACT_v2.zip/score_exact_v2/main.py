import math
import os
from datetime import date
from typing import Any, Optional

import httpx
from dotenv import load_dotenv
from fastapi import FastAPI, HTTPException, Query
from fastapi.middleware.cors import CORSMiddleware

load_dotenv()
API_BASE = "https://v3.football.api-sports.io"
API_TIMEOUT = float(os.getenv("API_TIMEOUT", "20"))

app = FastAPI(title="SCORE EXACT API", version="0.2.0")
origins = [x.strip() for x in os.getenv("CORS_ORIGINS", "http://localhost:8080").split(",") if x.strip()]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=False,
    allow_methods=["GET"],
    allow_headers=["*"],
)


async def football_get(path: str, params: dict[str, Any]) -> dict[str, Any]:
    # Read the secret at runtime; never return it in API responses.
    api_key = os.getenv("API_FOOTBALL_KEY", "").strip()
    if not api_key or api_key == "COLLER_LA_CLE_ICI_COTE_SERVEUR":
        raise HTTPException(status_code=503, detail="Clé API non configurée côté serveur.")

    try:
        async with httpx.AsyncClient(timeout=API_TIMEOUT) as client:
            response = await client.get(
                f"{API_BASE}/{path}",
                params=params,
                headers={"x-apisports-key": api_key},
            )
            response.raise_for_status()
            data = response.json()
    except httpx.TimeoutException:
        raise HTTPException(status_code=504, detail="Délai dépassé auprès du fournisseur football.")
    except httpx.HTTPStatusError as exc:
        # Do not expose request headers or API credentials.
        raise HTTPException(status_code=502, detail=f"Fournisseur football indisponible (HTTP {exc.response.status_code}).")
    except (httpx.HTTPError, ValueError):
        raise HTTPException(status_code=502, detail="Impossible de lire la réponse du fournisseur football.")

    errors = data.get("errors")
    if errors:
        raise HTTPException(status_code=502, detail={"provider_errors": errors})
    return data


@app.get("/health")
def health():
    return {
        "app": "SCORE EXACT",
        "version": app.version,
        "status": "ok",
        "api_key_configured": bool(os.getenv("API_FOOTBALL_KEY", "").strip()),
    }


@app.get("/api/leagues")
async def leagues(season: int = Query(ge=2000, le=2100), country: Optional[str] = None):
    params: dict[str, Any] = {"season": season}
    if country:
        params["country"] = country
    data = await football_get("leagues", params)
    return {"results": data.get("response", []), "paging": data.get("paging", {})}


@app.get("/api/fixtures")
async def fixtures(
    day: date = Query(default_factory=date.today),
    league: Optional[int] = Query(default=None, ge=1),
    season: Optional[int] = Query(default=None, ge=2000, le=2100),
    timezone: str = "Africa/Ndjamena",
):
    params: dict[str, Any] = {"date": day.isoformat(), "timezone": timezone}
    if league is not None:
        params["league"] = league
    if season is not None:
        params["season"] = season
    data = await football_get("fixtures", params)
    return {"results": data.get("response", []), "paging": data.get("paging", {})}


def poisson(k: int, lam: float) -> float:
    if lam < 0:
        return 0.0
    return math.exp(-lam) * (lam ** k) / math.factorial(k)


def top_scores(home_lambda: float, away_lambda: float, max_goals: int = 7, limit: int = 5):
    scores = []
    for home_goals in range(max_goals + 1):
        for away_goals in range(max_goals + 1):
            probability = poisson(home_goals, home_lambda) * poisson(away_goals, away_lambda)
            scores.append({"score": f"{home_goals}-{away_goals}", "probability": round(probability, 6), "probability_percent": round(probability * 100, 2)})
    return sorted(scores, key=lambda item: item["probability"], reverse=True)[:limit]


async def recent_team_matches(team_id: int, last: int, timezone: str):
    data = await football_get("fixtures", {"team": team_id, "last": last, "timezone": timezone})
    finished = []
    for item in data.get("response", []):
        fixture = item.get("fixture", {})
        status = fixture.get("status", {}).get("short")
        goals = item.get("goals", {})
        halftime = item.get("score", {}).get("halftime", {})
        if status in {"FT", "AET", "PEN"} and goals.get("home") is not None and halftime.get("home") is not None:
            finished.append(item)
    return finished


def summarize_team(team_id: int, matches: list[dict[str, Any]]) -> dict[str, Any]:
    ht_for = ht_against = ft_for = ft_against = 0
    home_count = away_count = 0
    for match in matches:
        teams = match.get("teams", {})
        is_home = teams.get("home", {}).get("id") == team_id
        if is_home:
            home_count += 1
            ht_for += match["score"]["halftime"]["home"]
            ht_against += match["score"]["halftime"]["away"]
            ft_for += match["goals"]["home"]
            ft_against += match["goals"]["away"]
        else:
            away_count += 1
            ht_for += match["score"]["halftime"]["away"]
            ht_against += match["score"]["halftime"]["home"]
            ft_for += match["goals"]["away"]
            ft_against += match["goals"]["home"]
    count = len(matches)
    return {
        "matches_used": count,
        "home_matches": home_count,
        "away_matches": away_count,
        "ht_goals_for_per_match": round(ht_for / count, 3),
        "ht_goals_against_per_match": round(ht_against / count, 3),
        "ft_goals_for_per_match": round(ft_for / count, 3),
        "ft_goals_against_per_match": round(ft_against / count, 3),
    }


@app.get("/api/team/recent")
async def team_recent(
    team_id: int = Query(ge=1),
    last: int = Query(default=10, ge=5, le=20),
    timezone: str = "Africa/Ndjamena",
):
    matches = await recent_team_matches(team_id, last, timezone)
    return {"team_id": team_id, "requested": last, "matches": matches, "statistics": summarize_team(team_id, matches) if matches else None}


@app.get("/api/predict")
async def predict(
    home_team: int = Query(ge=1),
    away_team: int = Query(ge=1),
    last: int = Query(default=10, ge=5, le=20),
    timezone: str = "Africa/Ndjamena",
):
    if home_team == away_team:
        raise HTTPException(status_code=422, detail="Les deux identifiants d'équipe doivent être différents.")

    home_matches, away_matches = await __import__("asyncio").gather(
        recent_team_matches(home_team, last, timezone),
        recent_team_matches(away_team, last, timezone),
    )
    minimum = 5
    if len(home_matches) < minimum or len(away_matches) < minimum:
        return {
            "status": "AUCUNE SELECTION",
            "reason": "Données historiques insuffisantes pour une prédiction prudente.",
            "matches_available": {"home": len(home_matches), "away": len(away_matches)},
            "minimum_required_per_team": minimum,
        }

    home = summarize_team(home_team, home_matches)
    away = summarize_team(away_team, away_matches)

    # Blend each team's scoring rate with the opponent's concession rate.
    home_ht = (home["ht_goals_for_per_match"] + away["ht_goals_against_per_match"]) / 2
    away_ht = (away["ht_goals_for_per_match"] + home["ht_goals_against_per_match"]) / 2
    home_ft = (home["ft_goals_for_per_match"] + away["ft_goals_against_per_match"]) / 2
    away_ft = (away["ft_goals_for_per_match"] + home["ft_goals_against_per_match"]) / 2

    ht_scores = top_scores(home_ht, away_ht, max_goals=5)
    ft_scores = top_scores(home_ft, away_ft, max_goals=7)
    top_probability = ht_scores[0]["probability_percent"]
    confidence = "faible" if top_probability < 18 else "modérée" if top_probability < 25 else "à interpréter avec prudence"

    return {
        "status": "analysis_ready",
        "method": "Poisson indépendant alimenté par les moyennes des derniers matchs terminés",
        "sample": {"home": home["matches_used"], "away": away["matches_used"]},
        "team_statistics": {"home": home, "away": away},
        "expected_goals": {
            "half_time": {"home": round(home_ht, 3), "away": round(away_ht, 3)},
            "full_time": {"home": round(home_ft, 3), "away": round(away_ft, 3)},
        },
        "half_time": ht_scores,
        "full_time": ft_scores,
        "confidence": confidence,
        "warning": "Probabilités indicatives, non garanties. Modèle de base non calibré; il ne tient pas encore compte des compositions, absences, force des adversaires ni des confrontations directes.",
    }


@app.get("/api/analysis")
def manual_analysis(
    home_ht: float = Query(0.55, ge=0, le=5),
    away_ht: float = Query(0.35, ge=0, le=5),
    home_ft: float = Query(1.35, ge=0, le=8),
    away_ft: float = Query(1.05, ge=0, le=8),
):
    return {
        "method": "Poisson indépendant (mode manuel/prototype)",
        "half_time": top_scores(home_ht, away_ht, max_goals=5),
        "full_time": top_scores(home_ft, away_ft, max_goals=7),
        "warning": "Estimations conditionnées par les moyennes saisies; ce mode ne constitue pas une garantie.",
    }
