SCORE EXACT API - VERSION 0.2

1) Installer Python 3.10 ou plus récent.
2) Dans le dossier du projet : python -m venv .venv
3) Activer l'environnement virtuel.
4) Installer : pip install -r requirements.txt
5) Copier .env.example vers .env.
6) Ouvrir .env et remplacer la valeur API_FOOTBALL_KEY par votre clé API-Football.
   Ne jamais publier .env, envoyer la clé dans un chat, ni l'intégrer dans l'application Android.
7) Lancer : uvicorn main:app --host 0.0.0.0 --port 8000
8) Vérifier : http://127.0.0.1:8000/health
9) Documentation interactive : http://127.0.0.1:8000/docs

ENDPOINTS
GET /health
GET /api/leagues?season=2026
GET /api/fixtures?day=2026-11-26&timezone=Africa/Ndjamena
GET /api/team/recent?team_id=33&last=10
GET /api/predict?home_team=33&away_team=34&last=10
GET /api/analysis (mode manuel de test)

IMPORTANT
- /api/predict utilise les 5 à 20 derniers matchs terminés disponibles et les scores à la mi-temps.
- Si moins de 5 matchs exploitables sont disponibles pour une équipe, le résultat est AUCUNE SELECTION.
- Le modèle reste une première version statistique. Il n'intègre pas encore les absences, compositions, confrontations directes ou calibration historique.
- Les probabilités ne garantissent jamais le résultat d'un match.
